/* MindfulPath – audio mapping.
   Paths are RELATIVE to your site, so they work on any device once the
   /audio folder is uploaded next to your index.html. */
const MINDFUL_AUDIO = {
  // Unwind > Guided relaxation
  "focused-attention":   { title: "10 Minutes of Focused Attention",   src: "audio/focused-attention.mp3" },
  "imagine-better":      { title: "Imagine a Better Outcome",          src: "audio/imagine-better-outcome.mp3" },
  "future-you":          { title: "Future You Has It Under Control",   src: "audio/future-you.mp3" },
  "guided-mindfulness":  { title: "Guided Mindfulness Meditation",     src: "audio/guided-mindfulness.mp3" },

  // Unwind > Ambient sound
  "healing-music":       { title: "Healing Meditation Music",          src: "audio/healing-meditation-music.mp3" },

  // Unwind > Unwind after work
  "reset-decompress":    { title: "Reset: Decompress Your Body and Mind", src: "audio/reset-decompress.mp3" },

  // Unwind > Quiet your thoughts
  "peaceful-mind":       { title: "A Peaceful Mind · Saurabh Bothra Yoga", src: "audio/peaceful-mind.mp3" },

  // Extra file you uploaded (not assigned to any option yet)
  "letting-go":          { title: "Letting Go of Your Day",            src: "audio/letting-go-of-your-day.mp3" }
};

/* One shared player so only one track plays at a time. */
const MindfulPlayer = (() => {
  const audio = new Audio();
  audio.preload = "none";
  return {
    audio,
    play(key) {
      const item = MINDFUL_AUDIO[key];
      if (!item) { console.warn("No audio for", key); return; }
      if (!audio.src.endsWith(item.src)) audio.src = item.src;
      audio.currentTime = 0;
      return audio.play();
    },
    pause() { audio.pause(); },
    toggle(key) {
      const item = MINDFUL_AUDIO[key];
      if (item && audio.src.endsWith(item.src) && !audio.paused) audio.pause();
      else this.play(key);
    }
  };
})();

/* Usage: give any option element data-audio="<key>", e.g.
     <button data-audio="focused-attention">10 Minutes of Focused Attention</button>
   or call MindfulPlayer.play('focused-attention') from your own click handler. */
document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-audio]");
  if (el) MindfulPlayer.toggle(el.dataset.audio);
});
